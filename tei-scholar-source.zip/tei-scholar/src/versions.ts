// Version helpers for the update check (no VS Code dependency, so they can be unit-tested).

export interface Found { version: string; url: string; }

/** Compare dotted versions numerically: 1 if a > b, -1 if a < b, 0 if equal. */
export function compareVersions(a: string, b: string): number {
  const pa = a.split('.').map(n => parseInt(n, 10) || 0), pb = b.split('.').map(n => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] ?? 0) - (pb[i] ?? 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

/** Pick the newest tei-scholar-X.Y.Z.vsix from a GitHub "contents" listing. */
export function newestVsix(listing: { name?: string; download_url?: string | null; type?: string }[]): Found | undefined {
  let best: Found | undefined;
  for (const f of listing) {
    const m = /^tei-scholar-(\d+(?:\.\d+)*)\.vsix$/.exec(f.name || '');
    if (!m || f.type === 'dir' || !f.download_url) continue;
    if (!best || compareVersions(m[1], best.version) > 0) best = { version: m[1], url: f.download_url };
  }
  return best;
}

