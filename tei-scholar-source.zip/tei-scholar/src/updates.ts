// Update check: looks for tei-scholar-X.Y.Z.vsix files in the project's
// GitHub repository and offers to install a newer one.

import * as vscode from 'vscode';
import * as https from 'https';
import * as http from 'http';
import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';

const DAY = 24 * 60 * 60 * 1000;

import { Found, compareVersions, newestVsix } from './versions';

function get(url: string, binary: boolean, redirects = 5): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith('http://') ? http : https;
    const req = lib.get(url, { headers: { 'User-Agent': 'tei-scholar-update-check', Accept: binary ? '*/*' : 'application/vnd.github+json' }, timeout: 20000 }, res => {
      const code = res.statusCode || 0;
      if (code >= 300 && code < 400 && res.headers.location && redirects > 0) {
        res.resume();
        resolve(get(new URL(res.headers.location, url).toString(), binary, redirects - 1));
        return;
      }
      if (code !== 200) { res.resume(); reject(new Error(`HTTP ${code} from ${url}`)); return; }
      const chunks: Buffer[] = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks)));
      res.on('error', reject);
    });
    req.on('timeout', () => req.destroy(new Error('timed out')));
    req.on('error', reject);
  });
}

export function registerUpdates(ctx: vscode.ExtensionContext) {
  const cfg = () => vscode.workspace.getConfiguration('teiScholar.updates');
  const current = String(ctx.extension.packageJSON.version || '0.0.0');

  async function latest(): Promise<Found | undefined> {
    const repo = (cfg().get<string>('repository') || '').trim();
    if (!repo) return undefined;
    const api = (cfg().get<string>('apiBase') || 'https://api.github.com').replace(/\/+$/, '');
    const body = await get(`${api}/repos/${repo}/contents/`, false);
    return newestVsix(JSON.parse(body.toString('utf8')));
  }

  async function install(found: Found) {
    await vscode.window.withProgress({ location: vscode.ProgressLocation.Notification, title: `Installing TEI Scholar ${found.version}…` }, async () => {
      const data = await get(found.url, true);
      if (data.length < 4 || data[0] !== 0x50 || data[1] !== 0x4b) throw new Error('The download is not a .vsix package.');
      const file = path.join(os.tmpdir(), `tei-scholar-${found.version}.vsix`);
      fs.writeFileSync(file, data);
      await vscode.commands.executeCommand('workbench.extensions.installExtension', vscode.Uri.file(file));
    });
    const pick = await vscode.window.showInformationMessage(`TEI Scholar ${found.version} is installed. Reload the window to start using it.`, 'Reload now');
    if (pick === 'Reload now') vscode.commands.executeCommand('workbench.action.reloadWindow');
  }

  async function check(manual: boolean) {
    let found: Found | undefined;
    try {
      found = await latest();
    } catch (e) {
      if (manual) vscode.window.showWarningMessage(`Could not check for TEI Scholar updates: ${(e as Error).message}`);
      return;
    }
    await ctx.globalState.update('updates.lastCheck', Date.now());
    if (!found || compareVersions(found.version, current) <= 0) {
      if (manual) vscode.window.showInformationMessage(`TEI Scholar ${current} is the latest version.`);
      return;
    }
    if (!manual && ctx.globalState.get<string>('updates.skipped') === found.version) return;
    const repo = cfg().get<string>('repository');
    const choice = await vscode.window.showInformationMessage(
      `A new version of TEI Scholar is available: ${found.version} (you have ${current}).`,
      'Install', 'What’s new', 'Skip this version');
    if (choice === 'Install') {
      try { await install(found); } catch (e) {
        const again = await vscode.window.showErrorMessage(`Installing the update failed: ${(e as Error).message}`, 'Open download page');
        if (again) vscode.env.openExternal(vscode.Uri.parse(`https://github.com/${repo}`));
      }
    } else if (choice === 'What’s new') {
      vscode.env.openExternal(vscode.Uri.parse(`https://github.com/${repo}/blob/HEAD/CHANGELOG.md`));
    } else if (choice === 'Skip this version') {
      await ctx.globalState.update('updates.skipped', found.version);
    }
  }

  ctx.subscriptions.push(vscode.commands.registerCommand('teiScholar.checkForUpdates', () => check(true)));

  // automatic check: at most once a day, a little after start-up
  if (cfg().get<boolean>('checkAutomatically', true)) {
    const last = ctx.globalState.get<number>('updates.lastCheck', 0);
    if (Date.now() - last > DAY) {
      const t = setTimeout(() => check(false), 15000);
      ctx.subscriptions.push({ dispose: () => clearTimeout(t) });
    }
  }
}
