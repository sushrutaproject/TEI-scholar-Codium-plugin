import { compareVersions, newestVsix } from '../src/versions';
let fails = 0;
const check = (n: string, ok: boolean, x = '') => { console.log((ok ? 'PASS ' : 'FAIL ') + n + (ok ? '' : ' ' + x)); if (!ok) fails++; };
check('0.10.0 > 0.9.9', compareVersions('0.10.0', '0.9.9') === 1);
check('0.5.1 > 0.5.0', compareVersions('0.5.1', '0.5.0') === 1);
check('equal', compareVersions('0.6.0', '0.6') === 0);
check('older', compareVersions('0.4.0', '0.5.1') === -1);
const listing = [
  { name: 'README.md', type: 'file', download_url: 'u/readme' },
  { name: 'tei-scholar-0.4.0.vsix', type: 'file', download_url: 'u/4' },
  { name: 'tei-scholar-0.10.0.vsix', type: 'file', download_url: 'u/10' },
  { name: 'tei-scholar-0.5.1.vsix', type: 'file', download_url: 'u/51' },
  { name: 'tei-scholar-source.zip', type: 'file', download_url: 'u/zip' },
  { name: 'src', type: 'dir', download_url: null },
];
const n = newestVsix(listing);
check('newest vsix picked numerically', n?.version === '0.10.0' && n.url === 'u/10', JSON.stringify(n));
check('no vsix -> undefined', newestVsix([{ name: 'x.txt', type: 'file', download_url: 'x' }]) === undefined);
console.log(fails ? `${fails} FAILED` : 'all passed');
process.exit(fails ? 1 : 0);
